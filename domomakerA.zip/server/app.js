//Obligitory Github Actions Test Line
const path = require('path');
const express = require('express');
const compression = require('compression');
const favicon = require('serve-favicon');
const mongoose = require('mongoose');
const expressHandlebars = require('express-handlebars');
const helmet = require('helmet');

const router = require('./router.js');

const port = process.env.PORT || process.env.NODE_PORT || 3000;

const dbURI = 'mongodb+srv://smd6167_db_user:XQdJpy2V9LTJEE05@cluster0.lx0m3rp.mongodb.net/DomoMaker';
mongoose.connect(dbURI).catch((err) => {
    if(err){
        console.log('Could not connect to database');
        throw err;
    }
});
console.log(`Connecting to MongoDB at ${dbURI}`);

const app = express();

app.use(helmet());
app.use('/assets', express.static(path.resolve(`${__dirname}/../hosted`)));
app.use(favicon(`${__dirname}/../hosted/img/favicon.png`));
app.use(compression());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.engine('handlebars', expressHandlebars.engine({ defaultLayout: '' }));
app.set('view engine', 'handlebars');
app.set('views', `${__dirname}/../views`);

router(app);

app.listen(port, (err) => {
    if(err){throw err;}
    console.log(`Listening on port ${port}`);
});